//
//  local.env.swift
//  EtiK_AFP
//
//  Created by Sylvain Leguay on 27/10/2023.
//

import Foundation

let apiKey = "patqAU8wkyv8GOO7a.95c0cad319fb20f43f7d41ded3b460310692f183afe1cd74697b639d777a7831"
